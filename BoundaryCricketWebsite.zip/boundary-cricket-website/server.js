require('dotenv').config();
const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const DEMO_MODE = String(process.env.DEMO_MODE || 'true').toLowerCase() !== 'false';
const API_BASE = (process.env.CRICKET_API_BASE || 'https://cricketliveapi.com/api/v1/cricket').replace(/\/$/, '');
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const demoMatches = [
 { match_id:'demo-1', teams:'India vs Australia', team1:'India', team2:'Australia', format:'T20', status:'DEMO • illustrative score', score:'186/4 (20.0 ov)', venue:'Demo Cricket Ground', innings:[
   {team:'India', score:'186/4', overs:'20.0', runRate:'9.30', batting:[{name:'A. Example',runs:62,balls:38,fours:6,sixes:2,out:true},{name:'B. Sample',runs:48,balls:25,fours:4,sixes:2,out:false},{name:'C. Demo',runs:17,balls:10,fours:1,sixes:1,out:false}], bowling:[{name:'M. Bowler',overs:'4.0',maidens:0,runs:34,wickets:2,economy:'8.50'}]},
   {team:'Australia',score:'142/3',overs:'15.2',runRate:'9.26',batting:[{name:'D. Sample',runs:52,balls:34,fours:5,sixes:2,out:false},{name:'E. Example',runs:28,balls:16,fours:2,sixes:2,out:false}],bowling:[{name:'R. Demo',overs:'3.2',maidens:0,runs:31,wickets:1,economy:'9.30'}]} ]},
 { match_id:'demo-2', teams:'England vs Pakistan', team1:'England', team2:'Pakistan', format:'T20', status:'DEMO • illustrative score', score:'165/6 (20.0 ov)', venue:'Demo Oval', innings:[{team:'England',score:'165/6',overs:'20.0',runRate:'8.25',batting:[{name:'F. Example',runs:45,balls:30,fours:4,sixes:1,out:true}],bowling:[{name:'P. Sample',overs:'4.0',maidens:0,runs:29,wickets:2,economy:'7.25'}]}]},
 { match_id:'demo-3', teams:'South Africa vs New Zealand', team1:'South Africa', team2:'New Zealand', format:'ODI', status:'DEMO • upcoming example', score:'Match not started', venue:'Demo Stadium', innings:[] }
];

app.get('/api/config', (req,res) => res.json({mode: DEMO_MODE ? 'demo' : 'live', provider: 'CricketLiveApi-compatible endpoint', configured: Boolean(process.env.CRICKET_API_TOKEN && process.env.CRICKET_API_TOKEN !== 'replace_with_your_api_token')}));
app.get('/api/matches/live', async (req,res) => {
 if (DEMO_MODE) return res.json({mode:'demo', data:{matches:demoMatches}});
 if (!process.env.CRICKET_API_TOKEN || process.env.CRICKET_API_TOKEN === 'replace_with_your_api_token') return res.status(503).json({error:'API token missing. Add CRICKET_API_TOKEN to your .env file.'});
 try {
   const response = await fetch(`${API_BASE}/matches/live`, {headers:{Authorization:`Bearer ${process.env.CRICKET_API_TOKEN}`, Accept:'application/json'}, signal:AbortSignal.timeout(12000)});
   const body = await response.json().catch(()=>({}));
   if (!response.ok) return res.status(response.status).json({error:body.message || `Cricket API returned ${response.status}`, provider:body});
   res.set('Cache-Control','no-store'); res.json({mode:'live', data:body.data || body});
 } catch(e) { res.status(502).json({error:'Could not reach cricket data provider. Check network, provider URL, and token.', detail:e.message}); }
});
app.get('/api/scorecard/:id', async (req,res) => {
 const id = req.params.id;
 if (DEMO_MODE) {
   const match = demoMatches.find(m=>m.match_id===id);
   if (!match) return res.status(404).json({error:'Demo match not found'});
   return res.json({mode:'demo', data:match});
 }
 if (!process.env.CRICKET_API_TOKEN || process.env.CRICKET_API_TOKEN === 'replace_with_your_api_token') return res.status(503).json({error:'API token missing. Add CRICKET_API_TOKEN to your .env file.'});
 if (!/^[a-zA-Z0-9_-]+$/.test(id)) return res.status(400).json({error:'Invalid match ID'});
 try {
   const response = await fetch(`${API_BASE}/scorecard/${encodeURIComponent(id)}`, {headers:{Authorization:`Bearer ${process.env.CRICKET_API_TOKEN}`,Accept:'application/json'}, signal:AbortSignal.timeout(12000)});
   const body = await response.json().catch(()=>({}));
   if (!response.ok) return res.status(response.status).json({error:body.message || `Cricket API returned ${response.status}`, provider:body});
   res.set('Cache-Control','no-store'); res.json({mode:'live', data:body.data || body});
 } catch(e) { res.status(502).json({error:'Could not fetch scorecard from provider.',detail:e.message}); }
});
app.get('*', (req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Boundary Cricket running at http://localhost:${PORT} (${DEMO_MODE?'DEMO MODE':'API MODE'})`));
